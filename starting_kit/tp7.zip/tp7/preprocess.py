import warnings
warnings.filterwarnings('ignore')
from sklearn.ensemble import RandomForestClassifier
from sklearn.decomposition import PCA
from dataManager import Manager as DataManager

data_dir = 'public_data'             
data_name = 'malaria'
D = DataManager(data_name, data_dir, replace_missing=True)
X = D.data['X_train']
CATEGORICAL_FEATURES = [0,5,7,14,15,16]
X = X[:,CATEGORICAL_FEATURES]

class  preprocess(BaseEstimator):
    def __init__(self, n_pca):
        self.mod = RandomForestClassifier()
        self.pca = PCA(n_components = n_pca)

    def fit(self, X, y):
        self.mod.fit(X, y)
        self.pca.fit(X)
        return self

    def transform(self, X):
        liste = []
        estimator = RandomForestClassifier(n_estimators = 10)
        estimator.fit(X_train)
        for i in range(data.shape[0]):
            if estimator.predict(X)[i] != -1 :
                liste.append(i)
        X = X[liste,:]
        X_1 = self.mod.transform(X)
        X_2 = self.pca.transform(X)
        return X_new
