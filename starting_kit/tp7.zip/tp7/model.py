


import numpy as np
from sklearn.externals import joblib
from sklearn.ensemble import RandomForestClassifier
from preprocess import preprocess

#un probleme au niveau de l'appel de preprocess à cause de data_manager qui n'est surement pas instalé sur nos ordinateurs




class model (BaseEstimator):
    def __init__(self, n_pca):
       
        self.num_train_samples=11077
        self.num_feat=6
        self.num_labels=1
        self.is_trained=False
        self.preprocess = preprocess(n_pca)
        Selt.mod = RandomForestClassifier()
    def fit(self, X, y):
        
        if X.ndim>1: self.num_feat = X.shape[1]
        if y.ndim>1: self.num_labels = y.shape[1]
        
        X_preprocess = self.preprocess.transform(X)
        self.mod.fit(X_preprocess, y)
        self.is_trained = True
    
    def predict(self, X):
        
        num_test_samples = X.shape[0]
        if X.ndim>1: num_feat = X.shape[1]
        y = np.zeros([num_test_samples, self.num_labels])
        
        
        X_preprocess = self.preprocess.transform(X)
        y = self.mod.predict(X_preprocess)
        return y
    
    def save(self, path="./"):
        joblib.dump(self.clf, path)
        return self
    
    def load(self, path="./"):
        joblib.load(self.clf, path)
        return self

    def main():
        #nous n'avons pas eu le temps de le finir à cause du manque de temps